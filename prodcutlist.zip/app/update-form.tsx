'use client'

import { useFormState, useFormStatus } from "react-dom"
import { updateProduct, findProduct } from "@/lib/actions"
import { useEffect, useRef, useState } from "react"
import toast from 'react-hot-toast'
import FileUpload from "./FileUpload"

export default function UpdateForm({
    _id,
}: {
    _id: string
}) {
   
    const [state, formAction] = useFormState(updateProduct, {
        message: '',
    })
  
     
    const { pending } = useFormStatus()

    const ref = useRef<HTMLFormElement>(null)
  
    const [productName, setProductName] = useState("")

    // useEffect(() => {
    //     const updateViews = async () => {
    //         const prodname = res.prodData.name;
    //       setProductName(prodname);
    //     }
     
    //     updateViews()
    //   }, [])  
      
      //     name : '',
    //     // image : '',
    //     // price : '',
    //     // rating : ''
    // )


    return (
        <div>

        <form action={async (formdata) => {
          
            const res = await findProduct(formdata)

            //console.log(res)
            const prodname = res.prodData.name;
            console.log(prodname);
            setProductName(prodname);

            //console.log(res.prodData.name)

          // console.log(postValues.name)
 
            
            //setPostValues([...res]);
        
          }}
        > 
            <input type="hidden" name="_id" value={_id} />

            {/* <button type="submit" disabled={pending} className="btn btn-ghost">
                Update
            </button> */}

            <button type="submit" disabled={pending} className="btn btn-ghost"
                onClick={() => (document.getElementById('my_modal_edit')! as any).showModal()
                }
            >
                Update
            </button>
        </form>

            <div>
                <dialog id="my_modal_edit" className="modal">
                    <div className="modal-box">
                        <h2 className="text-2xl font-bold pm-4">Update Product</h2>

                        <FileUpload />

                      
                        <form ref={ref} action={formAction}>
                       
                            <div className="form-control w-full max-w-xs py-4">
                                <label htmlFor="name">Name</label>
                                <input
                                    type="text"
                                    id="name"
                                    name="name"
                                    className="input input-bordered w-full max-w-xs"          
                                    value={productName}                                    
                                    required
                                />
                            </div>
                            <button
                                className="btn btn-primary mr-3"
                                type="submit"
                                disabled={pending}
                            >
                                Save
                            </button>
                            <button
                                className="btn btn-ghost"
                                type="button"
                                onClick={() => (document.getElementById('my_modal_edit') as any).close()}
                            >
                                Back
                            </button>
                        </form> 
                    </div>
                </dialog>
            </div>

        </div>
    )

  }